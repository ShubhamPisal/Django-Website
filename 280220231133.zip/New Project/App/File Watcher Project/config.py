from datetime import date, datetime
import os.path
import shutil

# Created logpath & logfile......for current date..............
logpath = 'D:\\Django Project\\New Project\\App\\logs\\filewatcher\\'
if not os.path.exists(logpath):
    os.mkdir(logpath)

# Created to chek file pattern................................
file_path = 'D:\\Django Project\\New Project\\New folder\\'
file_path_new = 'D:\\Django Project\\New Project\\'

