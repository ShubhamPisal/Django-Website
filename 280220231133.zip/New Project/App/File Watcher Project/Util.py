import shutil
from config import * 

def function():
    ALC_file = file_path +'ALC'+str(date.today().strftime('%d%m%Y'))+'.ls'
    Dest_path = file_path_new +'ALC'+str(date.today().strftime('%d%m%Y'))+'.ls'
    if os.path.exists(ALC_file):
        shutil.move(ALC_file, Dest_path)
        