import time
from datetime import date, datetime
import logging
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler
from config import *
import os.path
from Util import *


if __name__ == '__main__':
    patterns = ['*.ls',]
    ignore_patterns = None
    ignore_directories = False
    case_sensitive = True
    my_event_handler = PatternMatchingEventHandler(patterns, ignore_patterns, ignore_directories, case_sensitive)
def on_created(event):
    time.sleep(2)
    function()
    logging.info(f'{event.src_path} file moved {file_path_new}')
    logging.info(f'{event.src_path} file created')

def on_deleted(event):
    print('')
    #print(f'Someone deleted {event.src_path}!')
    logging.info(f'{event.src_path} file deleted')
    
def on_modified(event):
    print('')
    #print(f'hey buddy, {event.src_path} has been modified')
    logging.info(f'{event.src_path} file  has been modified')

def on_moved(event):
    print('')
    #print(f'someone moved file {event.src_path} to {event.dest_path}')
    logging.info(f'{event.src_path} file moved to {event.dest_path}')

my_event_handler.on_created = on_created
my_event_handler.on_modified = on_modified
my_event_handler.on_moved = on_moved
my_event_handler.on_deleted = on_deleted

file_path = 'D:\\Django Project\\New Project\\New folder'
go_recursively = True
my_observer = Observer()
my_observer.schedule(my_event_handler, file_path, recursive=go_recursively)

my_observer.start()
logging.info('file watcher started')

try:
    while True:
        logging.basicConfig(filename=logpath+str(date.today().strftime('%d%m%Y'))+'.log' , filemode='a',force=True, level= logging.INFO, format='%(asctime)s %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p')
        time.sleep(1)
except KeyboardInterrupt:
    my_observer.stop()
    my_observer.join()
