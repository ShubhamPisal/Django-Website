from django.urls import path
from blog import views


#We need to add urls as we created the views in app & templet to see it in webpage
urlpatterns = [
    path('', views.home, name='blog-homePage'),
    path('Login', views.loginUser, name='blog-LoginPage'),
    path('Logout', views.logoutUser, name='blog-Logout'),
    path('ForgetPassword', views.forgetpassword, name='blog-ForgetPasswordPage'),
    path('SignUp/', views.signup, name='blog-SignUpPage'),
    path('Logedin', views.logedin, name='blog-LogedinPage'),
    # path('Register', views.register_request, name='register'),

]
