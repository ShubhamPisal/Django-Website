from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
# from captcha.fields import CaptchaField


# Create your forms here.

# Class created to form a 
# class MyForm(forms.Form):
#     captcha = CaptchaField()

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)

	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']

	