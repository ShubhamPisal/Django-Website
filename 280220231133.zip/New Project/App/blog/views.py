from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import logout, authenticate, login
from blog.forms import NewUserForm
#from blog.forms import MyForm  #captcha is not running so not require
from django.contrib import messages
from django.contrib.auth.models import User

# Create the home page view
def home(request):
    return render(request, 'Home.html',{'title' : 'Home'})

# Create the login page view
def loginUser(request):
    logintext = {'title' : 'Login Page',
               'enablecaptcha' : 0 ,
            
               }
          
    if request.method=='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # check if user has entered correct credentials
        user = authenticate(username=username, password=password)

        if user is not None:
            # A backend authenticated the credentials
            login(request, user)
            return redirect('/Logedin')

        else:
            # No backend authenticated the credentials
            messages.warning(request, 'Enter Correct Password!')
            return render(request, 'Login.html', logintext)

    return render(request, 'Login.html', logintext)

# Create the logout page view
def logoutUser(request):
    logout(request)
    return redirect('blog-LoginPage')
   
# Create the forgetpassword page view
def forgetpassword(request):
    return render(request, 'ForgetPassword.html', {'title' : 'Forget Password'})

# Create the signup page view
def signup(request):
    if request.method == 'POST':
        form = NewUserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created successfully for {username}!' )
            return redirect('blog-homePage')
    else:
        form = NewUserForm()
    return render (request, 'SignUp.html', {'title' : 'SignUp Page','form' : form})

# Create the logedin page view
def logedin(request):
    if request.user.is_anonymous:
         return redirect('/Login') 
    return render(request, 'Logedin.html', {'title' : 'Logedin'})

